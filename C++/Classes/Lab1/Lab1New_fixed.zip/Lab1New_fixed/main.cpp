#include "student.h"

int main() {
    Student student1;
    student1.setFirstName("Иван");
    student1.setLastName("Иванов");
    student1.setGradeMath(5);
    student1.setGradeC(5);

    Student student2;
    student2.setFirstName("Пётр");
    student2.setLastName("Петров");
    student2.setGradeMath(20); // Неверная оценка: будет заменена на 2
    student2.setGradeC(4);

    student1.printInfo();
    student2.printInfo();

    return 0;
}
